const handleSubmit = async function(e) {
    e.preventDefault()

    let cityFrom = document.querySelector('#from').value;
	let cityTo = document.querySelector('#to').value;
	let dateStart = document.querySelector('#departure').value;
	let dateEnd = document.querySelector('#arrival').value;

    if(cityFrom === ""){
		alert('Cannot proceed with empty origin');
		return;
	}
	//Check if destination city is empty
	if(cityTo === ""){
		alert('Cannot proceed with empty destination');
		return;
	}	

    let tripStart = new Date(dateStart);
	let tripEnd = new Date(dateEnd);
	let daysDiff = (tripEnd.getTime() - tripStart.getTime())/(1000*3600*24);

    let geoData = {};
    let weatherbitData= {};
    let pixabayData = {};

    const postGeo = await fetch('http://localhost:8080/cityTo',{
        method: 'POST',
        mode: 'cors',
        credentials: 'same-origin',
        headers: {
            'Content-Type' : 'application/json'
        },
        body: JSON.stringify({cityTo: cityTo})
    })

    try {
        const dataGeo = await postGeo.json();
        geoData = {
            country: dataGeo.geonames[0].countryName,
            city: dataGeo.geonames[0].name,
            latitude: dataGeo.geonames[0].lat,
            longitude: dataGeo.geonames[0].lng
        }

    } catch(error){
        console.log("Error:" + error)
    }

    const postWeatherbit = await fetch('http://localhost:8080/findWeather', {
        method: 'POST',
        mode: 'cors',
        credentials: 'same-origin',
        headers: {
            'Content-Type': 'application/json'
        },
        body: JSON.stringify(geoData)
    })

    try{
        weatherbitData = await postWeatherbit.json();
    } catch(error){
        console.log("Error:" + error)
    }

    const postPixabay = await fetch('http://localhost:8080/findImage',{
        method: 'POST',
        mode: 'cors',
        credentials: 'same-origin',
        headers: {
            'Content-Type': 'application/json'
        },
        body: JSON.stringify(geoData)
    })

    try{
        pixabayData = await postPixabay.json;
    }

    catch(error){
        console.log("Error:" + error);
    }

    document.getElementById('results').innerHTML=
     `
    <div id="timeTravel">
    <p>You are traveling from ${dateStart} till ${dateEnd}</p>
    <p>Your trip will be in the length of ${daysDiff} days</p>
    </div>
    <div id="paradise">
        <h3>Your destination is ${paradise.city}, ${paradise.country}</h3>
    </div>
    <h5>Here is an image of your destination city</h5>
    <img src="${pixaData.hits[0].webformatURL}" alt="img of ${paradise.city}">
    <h4>The weather probably will be</h4>
    <div>
        <p>High: ${weatherData.data[0].max_temp}</p>
        <p>Low:  ${weatherData.data[0].min_temp}</p>
    </div>
    `
}


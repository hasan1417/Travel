  // Setup empty JS object to act as endpoint for all routes
projectData = {};

// Require Express to run server and routes
const express = require('express')
const bodyParser = require('body-parser')
const cors= require('cors')
var path = require('path')
const node = require('node-fetch')
const dotenv= require('dotenv')
dotenv.config();
// Start up an instance of app
const app = express();
/* Middleware*/
//Here we are configuring express to use body-parser as middle-ware.
app.use(bodyParser.urlencoded({ extended: false }));
app.use(bodyParser.json());

// Cors for cross origin allowance
app.use(cors());
// Initialize the main project folder
app.use(express.static('dist'))

console.log(__dirname)

//GEO API
app.post('/cityTo', async function (req, res) {
	cityTo = req.body.cityTo;
	
	const responseTo = await fetch (`http://api.geonames.org/search?q=${cityTo}&username=${process.env.USERNAME}&type=json`);
	const geoNamesTo = await responseTo.json();
	res.json(geoNamesTo);
})

// Weatherbit API
app.post('/findWeather', async function (req, res) {
	const latitude = req.body.lat;
	const longitude = req.body.lon;
	
	const responseWeather = await fetch (`http://api.weatherbit.io/v2.0/forecast/daily?&lat=${req.body.lat}&lon=${req.body.lon}&key=${process.env.WEATHERBIT_API}`);
	const weatherBit = await responseWeather.json();
	res.json(weatherBit);
})

//Pixabay API

app.post('/findImage', async function (req, res) {
	const cityName = req.body.city;
	const responsePixa = await fetch (`https://pixabay.com/api/?key=${process.env.PIXABAY_API}&q=${city}&lang=en&image_type=photo`);
	let pixaBay = await responsePixa.json();
	//totalHits The number of images accessible through the API.
	if (pixaBay.totalHits > 0){
		//Image found
		res.json(pixaBay);
	}else {
		alert("The city isn't found, try another one")
	}
	
})

app.get('/', function (req, res) {
    //res.sendFile(path.resolve('src/client/views/index.html'))
	res.status(200).sendFile('dist/index.html')
})

// Setup Server
// designates what port the app will listen to for incoming requests
app.listen(8080, function () {
    console.log('Example app listening on port 8081!')
})

module.exports = app;